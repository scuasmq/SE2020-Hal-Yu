import platform

print(platform.platform())